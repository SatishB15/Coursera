'''
Write a program that uses a print statement to say
'hello world' as shown in 'Desired Output'.
'''
# the code below almost works
print "hello world"
